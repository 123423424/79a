<h1>Актуальные вопросы.</h1>
<p>
	Вопросы 3 темы
</p>

<?php
//$this->topicalAnswer()
	
?>
