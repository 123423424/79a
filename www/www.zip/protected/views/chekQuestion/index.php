<h1>
<?php	
    if (isset($this->param['h1'])) echo $this->param['h1'];
?>
</h1>

Нажмите на кнопку: 
<a class="btn btn-success" role="button" href="/questions">Далее</a>

