<?php
//if (Yii::app()->user->name != 'MaXiM'){die('вали от сюда!');} 
class SomeClass 
{
	public function zzz()
	{  
	   echo 'Gooood';
	}
    
  
}