$(document).ready(function(){  
    // $(".statys").click(function(){ }       
   //  alert('m');

$('.errorMessage').parent('.row').addClass('form-group has-error');

$('.has-error').find('input').addClass('form-control');
$('.has-error').find('label ').addClass('control-label');

















	 
}); // $(document).ready /
